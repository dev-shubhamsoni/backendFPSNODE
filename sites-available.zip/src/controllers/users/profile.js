const { sendSuccess, sendError } = require("../../utils/commonFunctions")
const { runQuery } = require("../../utils/executeQuery")

// Faculty Get Api's...

exports.facultyLanguage = async (req, res) => {
    try {
        const { facultyID } = req.query
        const data = await runQuery(`SELECT * FROM faculity_language WHERE faculityID = ?`, facultyID)
        return sendSuccess(res, { data: data, message: "Faculty Language List..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.facultyEducation = async (req, res) => {
    try {
        const { facultyID } = req.query
        const data = await runQuery(`SELECT * FROM faculity_education WHERE faculityID = ?`, facultyID)
        return sendSuccess(res, { data: data, message: "Faculty Education List..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.facultyCareerPreference = async (req, res) => {
    try {
        const { facultyID } = req.query
        const data = await runQuery(`SELECT * FROM faculity_career_preferences WHERE faculityID = ?`, facultyID)
        return sendSuccess(res, { data: data, message: "Faculty Career Preference..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.facultyCertificate = async (req, res) => {
    try {
        const { facultyID } = req.query
        const data = await runQuery(`SELECT * FROM faculity_certificate WHERE faculityID = ?`, facultyID)
        return sendSuccess(res, { data: data, message: "Faculty Certificate..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.facultyCityPreference = async (req, res) => {
    try {
        const { facultyID } = req.query
        const data = await runQuery(`SELECT * FROM faculity_city_preferences WHERE faculityID = ?`, facultyID)
        return sendSuccess(res, { data: data, message: "Faculty City Preference..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.facultyExperience = async (req, res) => {
    try {
        const { facultyID } = req.query
        const data = await runQuery(`SELECT * FROM faculity_experience WHERE faculityID = ?`, facultyID)
        return sendSuccess(res, { data: data, message: "Faculty Experience..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.facultySkill = async (req, res) => {
    try {
        const { facultyID } = req.query
        const data = await runQuery(`SELECT * FROM faculity_skill WHERE faculityID = ?`, facultyID)
        return sendSuccess(res, { data: data, message: "Faculty Skill..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.facultyAllData = async (req, res) => {
    try {
        const { facultyID } = req.query
        const data = await runQuery(`SELECT * FROM faculity_users WHERE faculityID = ?`, facultyID)
        return sendSuccess(res, { data: data, message: "Faculty All Data..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

