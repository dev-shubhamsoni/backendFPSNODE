const { sendError, sendSuccess } = require("../../utils/commonFunctions");
const { runQuery } = require("../../utils/executeQuery");
const { isValidJson } = require("../../utils/validator");
const WORK_PLACE_TYPE = ["On-Site", "Hybrid", "Remote"]
const JOBS_TYPE = ["Full Time", "Part Time", "Contract", "Hourly Basis", "Internship"]














// Old-code ->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

exports.searchJob = async (req, res) => {
    try {
        const {
            salary_minimum,
            salary_maximum,
            experience_minimum,
            experience_maximum,
            work_place_type,
            job_type,
            job_name,
            city_name,
            state_name,
        } = req.query

        let query = `select * from jobs j join cities c on j.city_id=c.city_id join states s on j.state_id=s.state_id where job_status = ?`
        const values = []
        values.push('Open')
        if ((salary_maximum && salary_minimum) && (parseInt(salary_minimum) && parseInt(salary_maximum))) {
            query += ` and salary_minimum >=? and salary_maximum<=?`
            values.push(salary_minimum, salary_maximum)
        }
        if ((experience_minimum && experience_maximum) && (parseInt(experience_minimum) && parseInt(experience_maximum))) {
            query += ` and experience_minimum >= ? and experience_maximum <= ?`
            values.push(experience_minimum, experience_maximum)
        }
        if (WORK_PLACE_TYPE.includes(work_place_type)) {
            query += ` and work_place_type=?`
            values.push(work_place_type)
        }
        if (JOBS_TYPE.includes(job_type)) {
            query += ` and job_type=?`
            values.push(job_type)
        }
        if (job_name) {
            query += ` and (job_title like ? or job_description like ?)`
            values.push(`%${job_name}%`, `%${job_name}%`)
        }
        if (city_name) {
            query += ` and city_name like ?`
            values.push(`%${city_name}%`)
        }
        if (state_name) {
            query += ` and state_name like ?`
            values.push(`%${state_name}%`)
        }
        const data = await runQuery(query, values)
        return sendSuccess(res, { data: data, message: "Job list..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.applyJob = async (req, res) => {
    try {
        const { job_id, u_id, rs_id } = req.body
        if (!job_id) {
            return sendError(res, { message: "Please select the job..." })
        } else if (!rs_id) {
            return sendError(res, { message: "Please select the resume..." })
        } else {
            const data = await runQuery(`select * from users where u_id = ?`, [u_id])
            if (data.length > 0) {
                await runQuery(`insert into job_applications set job_id = ?,u_id=?,rs_id=?`, [job_id, u_id, rs_id])
                return sendSuccess(res, { message: "Application has been applied..." })
            } else {
                return sendError(res, { message: "Your account is not found..." })
            }
        }
    } catch (error) {
        if (error.code == 'ER_NO_REFERENCED_ROW_2') {
            return sendError(res, { message: "Please select the valid job or resume..." })
        } else if (error.code == 'ER_DUP_ENTRY') {
            return sendError(res, { message: "Already applied..." })
        } else {
            return sendError(res, { message: error.message })
        }
    }
}

exports.answerSecreenQuestions = async (req, res) => {
    try {
        const { apl_id, ques_id, answer } = req.body
        if (!apl_id) {
            return sendError(res, { message: "Please apply to the job first..." })
        } else if (!ques_id) {
            return sendError(res, { message: "Please select the question..." })
        } else if (!answer || !isValidJson(answer)) {
            return sendError(res, { message: "Please valid the answer..." })
        } else {
            await runQuery(`insert into job_screening_questions_response set ques_id=?,apl_id=?,ans_text=?`, [ques_id, apl_id, answer])
            return sendSuccess(res, { message: "Answer has been submitted..." })
        }
    } catch (error) {
        if (error.code == 'ER_DUP_ENTRY') {
            return sendError(res, { message: "Already answered..." })
        }
        return sendError(res, { message: error.message })
    }
}

exports.appliedJobs = async ({body:{u_id}}, res) => {
    try {
        const data = await runQuery(`select *,s.state_name,c.city_name from job_applications ja join jobs j on ja.job_id=j.job_id join cities c on j.city_id= c.city_id join states s on s.state_id=j.state_id where ja.u_id =?`,[u_id])
        return sendSuccess(res, { data: data, message: "Applied jobs..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.saveJob = async ({body:{job_id, u_id}}, res) => {
    try {
        if (!job_id) {
            return sendError(res, { message: "Please select the job..." })
        }
        await runQuery(`insert into saved_jobs set job_id=?,u_id=?`, [job_id, u_id])
        return sendSuccess(res, { message: "Job has been saved..." })
    } catch (error) {
        if (error.code == 'ER_DUP_ENTRY') {
            return sendError(res, { message: "This job alredy saved..." })
        }
        return sendError(res, { message: error.message })
    }
}

exports.removeSavedJob = async (req, res) => {
    try {
        const { saved_id } = req.params
        await runQuery(`delete from saved_jobs where saved_id = ?`, [saved_id])
        return sendSuccess(res, { message: "Job has been removed..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.savedJobs = async ({body:{u_id}}, res) => {
    try {
        const data = await runQuery(`select *,s.state_name,c.city_name from saved_jobs sj join jobs j on sj.job_id=j.job_id join cities c on j.city_id= c.city_id join states s on s.state_id=j.state_id where sj.u_id=?`, [u_id])
        return sendSuccess(res, { data: data, message: "Saved jobs list..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}