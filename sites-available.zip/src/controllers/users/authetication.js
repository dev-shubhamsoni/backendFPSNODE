const { sendError, sendSuccess } = require("../../utils/commonFunctions");
const { runQuery } = require("../../utils/executeQuery");
const { UserProfile, UserResume } = require("../../utils/filesPath");
const { isValidMobileNumber, isValidEmail, isValidPassword, isValidDateFormat } = require("../../utils/validator");
const crypto = require('crypto')
const fs = require('fs');
const { generateOTP, sendOTPMessage, verifyOTP } = require("../../utils/messageSender");
const { createJWTToken } = require("../../utils/jwtHandler");

exports.registartionOTP = async ({ body: { phone_number } }, res) => {
    try {
        if (!isValidMobileNumber(phone_number)) {
            return sendError(res, { message: "Please enter valid phone number..." })
        }
        const data = await runQuery(`select 1 from users where u_phone_number = ?`, [phone_number])
        if (data.length <= 0) {
            const otpBody = generateOTP(phone_number)
            const msg = `FPSJOB - ${otpBody.otp} is your one time OTP for phone verification`
            const messageRes = await sendOTPMessage(phone_number, msg)
            if (messageRes.success == 1) {
                return sendSuccess(res, { data: messageRes, message: "OTP has been sent..." })
            } else {
                return sendError(res, { message: "Something went wrong..." })
            }

        } else {
            return sendError(res, { message: "Sorry, this number is already linked to another account..." })
        }
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.registartion = async (req, res) => {
    try {
        const { phone_number, hash, otp, email_id, full_name, state_id, city_id, fcm_token, added_by = 'APP' } = req.body
        if (!full_name) {
            return sendError(res, { message: "Please enter your name..." })
        } else if (!isValidMobileNumber(phone_number)) {
            return sendError(res, { message: "Please enter valid phone number..." })
        } else if (!isValidEmail(email_id)) {
            return sendError(res, { message: "Please enter valid email id..." })
        } else if (!state_id) {
            return sendError(res, { message: "Please select your state..." })
        } else if (!city_id) {
            return sendError(res, { message: "Please select your city..." })
        } else {
            const otpValidity = await verifyOTP(phone_number, hash, otp)
            if (!otpValidity) return sendError(res, { message: "Invalid otp..." })
            const query = `insert into users set u_full_name=?, u_phone_number=?, u_email_id=?, state_id=?, city_id=?, fcm_token=?, added_by=?`
            await runQuery(query, [full_name, phone_number, email_id, state_id, city_id, fcm_token, added_by])
            return sendSuccess(res, { data: [], message: "Registration has been completed..." })
        }

    } catch (error) {
        if (error.code == 'ER_DUP_ENTRY') {
            return sendError(res, { message: "Sorry, this number is already linked to another account..." })
        } else if (error.code == 'ER_NO_REFERENCED_ROW_2') {
            return sendError(res, { message: "Please select valid city or state..." })
        } else {
            return sendError(res, { message: error.message })
        }
    }
}

exports.registartionAdditionalInformation = async (req, res) => {
    try {
        const { u_id, bio, u_skills = ["NA"], address, linkedin_link = "NA" } = req.body
        if (!bio) {
            return sendError(res, { message: "Please enter your bio..." })
        } else if (!address) {
            return sendError(res, { message: "Please provide your full address..." })
        } else if (!Array.isArray(u_skills)) {
            return sendError(res, { message: "Please select atleast one skill..." })
        } else {
            const query = `update users set u_bio = ?, u_skills = ?, u_address = ?, linkedin_profile = ? where u_id = ?`
            await runQuery(query, [bio, JSON.stringify(u_skills), address, linkedin_link, u_id])
            return sendSuccess(res, { message: "Information has been updated successfully..." })
        }
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}


exports.mobileSendOTP = async ({ body: { phone_number } }, res) => {
    try {
        if (!isValidMobileNumber(phone_number)) {
            return sendError(res, { message: "Please enter valid phone number..." })
        }
        const data = await runQuery(`select 1 from users where u_phone_number = ?`, [phone_number])
        if (data.length > 0) {
            const otpBody = generateOTP(phone_number)
            const msg = `FPSJOB - ${otpBody.otp} is your one time OTP for phone verification`
            const messageRes = await sendOTPMessage(phone_number, msg)
            if (messageRes.success == 1) {
                return sendSuccess(res, { data: [otpBody.fullHash], message: "OTP has been sent..." })
            } else {
                return sendError(res, { message: "Something went wrong..." })
            }
        } else {
            return sendError(res, { message: "Sorry, account is not found on this number..." })
        }
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.mobileVerifyOTP = async ({ body: { phone_number, hash, otp, fcm_token = "NA" } }, res) => {
    try {
        if (!isValidMobileNumber(phone_number)) {
            return sendError(res, { message: "Please enter valid phone number..." })
        }
        const otpValidity = await verifyOTP(phone_number, hash, otp)
        if (!otpValidity) return sendError(res, { message: "Invalid otp..." })
        await runQuery(`update users set fcm_token = ? where u_phone_number = ?`, [fcm_token, phone_number])
        const data = await runQuery(`select * from users where u_phone_number = ?`, [phone_number])
        return sendSuccess(res, { data: [createJWTToken(data[0])], message: "Login successfully..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}


exports.signInWithEmailAndPwd = async ({ body: { email, password, fcm_token = "NA" } }, res) => {
    try {
        if (!isValidEmail(email)) {
            return sendError(res, { message: "Please enter valid email id..." })
        } else if (!password) {
            return sendError(res, { message: "Please enter your password..." })
        } else {
            const pwd = crypto
                .pbkdf2Sync(password, process.env.SHA_KEY, 1000, 64, `sha512`)
                .toString(`hex`);
            const data = await runQuery(`select * from users where u_email_id = ?`, [email])
            if (data.length > 0) {
                if (data[0].password == pwd) {
                    await runQuery(`update users set fcm_token = ? where u_email_id = ?`, [fcm_token, email])
                    return sendSuccess(res, { data: [createJWTToken(data[0])], message: "Logged in successfully..." })
                } else {
                    return sendError(res, { message: "Invalid password..." })
                }
            } else {
                return sendError(res, { message: "Invalid email id..." })
            }
        }
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}


exports.userProfile = async ({ body: { u_id } }, res) => {
    try {
        const data = await runQuery(`select * from users where u_id = ?`, [u_id])
        if (data.length > 0 && data[0].profile_image != null) {
            const imagePath = `${UserProfile}/${data[0].profile_image}`
            const image = fs.readFileSync(imagePath);
            data[0].profile_image = image.toString('base64')
            data[0].u_skills = JSON.parse(data[0].u_skills)
            const eduction = await runQuery(`select * from users_education where u_id=? order by create_at desc`, [u_id])
            const experience = await runQuery(`select * from users_work_experience where u_id=? order by create_at desc`, [u_id])
            data[0].eduction = eduction
            data[0].experience = experience
        }

        return sendSuccess(res, { data: data, message: "Your profile..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.setNewPassword = async ({ body: { u_id, password } }, res) => {
    try {
        if (!isValidPassword(password)) {
            return sendError(res, { message: "Password is invalid. It must be at least six characters long and contain at least one numeric digit and one special character." })
        }
        const pwd = crypto
            .pbkdf2Sync(password, process.env.SHA_KEY, 1000, 64, `sha512`)
            .toString(`hex`);
        await runQuery(`update users set password = ? where u_id =?`, [pwd, u_id])
        return sendSuccess(res, { data: [pwd], message: "Password has been created successfull..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.uploadProfileImage = async (req, res) => {
    try {
        if (req.file !== undefined) {
            const data = await runQuery(`select * from users where u_id =?`, [req.body.u_id])
            if (data.length > 0 && data[0].profile_image != null) {
                const imagePath = `${UserProfile}/${data[0].profile_image}`
                fs.unlinkSync(imagePath)
            }
            await runQuery(`update users set profile_image = ? where u_id =?`, [req.file.filename, req.body.u_id])
            return sendSuccess(res, { data: [], message: "Images uploded succesfully..." })
        } else {
            return sendError(res, { message: "Please select your profile photo..." })
        }
    } catch (error) {
        fs.unlinkSync(req.file.path)
        return sendError(res, { message: error.message })
    }
}


exports.uploadResume = async (req, res) => {
    try {
        if (req.file !== undefined) {
            const data = await runQuery(`select * from users where u_id = ?`, [req.body.u_id])
            if (data.length > 0) {
                await runQuery(`insert into users_resume set u_id =?, resume_original_name =?, resume_db_name =?`, [req.body.u_id, req.file.originalname, req.file.filename])
                return sendSuccess(res, { message: "Resume has been uploaded..." })
            } else {
                fs.unlinkSync(req.file.path)
                return sendError(res, { message: "Your account is not found..." })
            }
        } else {
            return sendError(res, { message: "Please select your resume..." })
        }
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.resumeList = async ({ body: { u_id } }, res) => {
    try {
        const data = await runQuery(`select * from users where u_id = ?`, [u_id])
        if (data.length > 0) {
            const result = await runQuery(`select rs_id id, resume_original_name resume_name, upload_time from users_resume where u_id =? and is_deleted =?`, [u_id, 0])
            return sendSuccess(res, { data: result, message: "Resume list..." })
        } else {
            return sendError(res, { message: "Your account is not found..." })
        }
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.viewResume = async ({ params: { rs_id } }, res) => {
    try {
        const data = await runQuery(`select * from users_resume where rs_id=?`, [rs_id])
        if (data.length == 0) return sendError(res, { message: "Resume not found..." })
        const resumePath = `${UserResume}/${data[0].resume_db_name}`
        fs.readFile(resumePath, (error, result) => {
            if (error) {
                return sendError(res, { message: error.message })
            } else {
                res.setHeader('Content-Type', 'application/pdf');
                res.setHeader('Content-Disposition', `attachment; filename=${data[0].resume_original_name}`)
                res.send(result)
            }
        })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.addEducation = async (req, res) => {
    try {
        const { institute_name, degree, field = "NA", started, completed, u_id } = req.body
        if (!institute_name) {
            return sendError(res, { message: "Please enter school or college name..." })
        } else if (!degree) {
            return sendError(res, { message: "Please enter your degree..." })
        } else if (!isValidDateFormat(started) || !isValidDateFormat(completed)) {
            return sendError(res, { message: "Please select the valid date..." })
        } else {
            await runQuery(`insert into users_education set u_id=?, institute_name=?, degree=?, major=?, start_date=?, end_date=?`, [u_id, institute_name, degree, field, started, completed])
            return sendSuccess(res, { message: "Added successfully..." })
        }
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}


exports.addExperience = async (req, res) => {
    try {
        const { institute_name, position, start_date, end_date, short_description = "NA", u_id } = req.body
        if (!institute_name) {
            return sendError(res, { message: "Please provide the institute name..." })
        } else if (!position) {
            return sendError(res, { message: "Please enter the position..." })
        } else if (!isValidDateFormat(start_date)) {
            return sendError(res, { message: "Please select the valid start date..." })
        } else {
            await runQuery(`insert into users_work_experience set u_id=?, institute_name=?, position=?, short_description=?, start_date=?, end_date=?`, [u_id, institute_name, position, short_description, start_date, end_date])
            return sendSuccess(res, { message: "Added successfully..." })
        }
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}