const { sendError, sendSuccess } = require("../../utils/commonFunctions")
const { runAdminQuery } = require("../../utils/executeQuery")
const { createJWTToken } = require("../../utils/jwtHandler")
const { isValidEmail, isValidMobileNumber, isAdminPassword } = require("../../utils/validator")
const crypto = require('crypto')

exports.adminLogin = async ({ body: { email_id, password } }, res) => {
    try {
        if (!isValidEmail(email_id)) {
            return sendError(res, { message: "Please select valid email id..." })
        } else if (!password) {
            return sendError(res, { message: "Please provide the password..." })
        } else {
            const data = await runAdminQuery(`select * from admin_info where admin_email = ?`, [email_id])
            if (data.length > 0) {
                const pwd = crypto
                    .pbkdf2Sync(password, process.env.ADMIN_PASSWORD_KEY, 1000, 64, `sha512`)
                    .toString(`hex`);
                if (data[0].admin_password == pwd) {
                    return sendSuccess(res, { data: [createJWTToken(data[0])], message: "You have logged in successfully..." })
                } else {
                    return sendError(res, { message: "Invalid passwordx..." })
                }
            } else {
                return sendError(res, { message: "Invalid email id..." })
            }
        }
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.adminRolesList = async (req, res) => {
    try {
        const roles = await runAdminQuery(`select * from roles`)
        return sendSuccess(res, { data: roles, message: "Roles list..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}


exports.addSubAdmins = async (req, res) => {
    try {
        // hrsupport@fpsjob.com -- use this mail for send mail 
        const { name, number, email, password, role_id } = req.body
        if (!name) {
            return sendError(res, { message: "Please provide the name..." })
        } else if (!isValidMobileNumber(number)) {
            return sendError(res, { message: "Please enter valid mobile number..." })
        } else if (!isValidEmail(email)) {
            return sendError(res, { message: "Please provide the valid email id..." })
        } else if (!isAdminPassword(password)) {
            return sendError(res, { message: "Password must be between 8 and 16 characters and include at least one uppercase letter, one lowercase letter, one digit, and one special character." })
        } else if (!role_id) {
            return sendError(res, { message: "Please select the role of admin..." })
        } else {
            const pwd = crypto
                .pbkdf2Sync(password, process.env.ADMIN_PASSWORD_KEY, 1000, 64, `sha512`)
                .toString(`hex`)
            await runAdminQuery(`insert into admin_info (admin_name,admin_number,admin_email,admin_password,role_id) values (?,?,?,?,?)`, [name, number, email, pwd, role_id])
            return sendSuccess(res, { message: "Account has been created..." })
        }
    } catch (error) {
        if (error.code == 'ER_NO_REFERENCED_ROW_2') {
            return sendError(res, { message: "Please select the valid role..." })
        } else if (error.code == 'ER_DUP_ENTRY') {
            return sendError(res, { message: "Mail id already used..." })
        }
        return sendError(res, { message: error.message })
    }
}

exports.addPermission = async ({ body: { permssion } }, res) => {
    try {
        if (!permssion) {
            return sendError(res, { message: "Please provide the name of permission..." })
        }
        await runAdminQuery(`insert into permissions(permission_name) values (?)`, [permssion])
        return sendSuccess(res, { message: "Permission has been added successfully..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}
exports.allPermissions = async (req,res)=>{
    try {
        const data = await runAdminQuery(`select * from role_permissions`)
        return sendSuccess(res,{data:data,message:"Permission..."})
    } catch (error) {
        return sendError(res,{message:error.message})
    }
}