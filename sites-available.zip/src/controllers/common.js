const { sendError, sendSuccess } = require("../utils/commonFunctions")
const { runQuery } = require("../utils/executeQuery")



exports.stateList = async (req, res) => {
    try {
        const data = await runQuery(`select * from states`)
        return sendSuccess(res, { data: data, message: "States..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.stateCities = async (req, res) => {
    try {
        const { id } = req.query
        const data = await runQuery(`select * from cities where state_id = ?`, id)
        return sendSuccess(res, { data: data, message: "State cities..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.cityList = async (req, res) => {
    try {
        const data = await runQuery(`select * from cities`, [])
        return sendSuccess(res, { data: data, message: "All City list..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.salaryList = async (req, res) => {
    try {
        const data = await runQuery(`SELECT * FROM tbl_salary`, [])
        return sendSuccess(res, { data: data, message: "Salary list..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.jobType = async (req, res) => {
    try {
        const data = await runQuery(`SELECT * FROM job_type`, [])
        const types = data.map(item => ({ type: item.type }));
        return sendSuccess(res, { data: types, message: "Job Type..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.jobLevel = async (req, res) => {
    try {
        const data = await runQuery(`SELECT level FROM job_level`, []);
        const levels = data.map(item => item.level);
        return sendSuccess(res, { data: levels, message: "Job Level..." });
    } catch (error) {
        return sendError(res, { message: error.message });
    }
};

exports.experience = async (req, res) => {
    try {
        const data = await runQuery(`SELECT * FROM tbl_experience`, [])
        return sendSuccess(res, { data: data, message: "Experience list..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.resultType = async (req, res) => {
    try {
        const data = await runQuery(`SELECT * FROM result_type`, [])
        return sendSuccess(res, { data: data, message: "Result Type list..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.categories = async (req, res) => {
    try {
        const data = await runQuery(`SELECT * FROM tbl_categories`, [])
        return sendSuccess(res, { data: data, message: "Categories list..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}

exports.subCategories = async (req, res) => {
    try {
        const { categoryID } = req.query
        const data = await runQuery(`SELECT * FROM tbl_functions WHERE CID = ?`, categoryID)
        return sendSuccess(res, { data: data, message: "Sub Categories list..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}




// -----------------------------------------------------------------------------------------------------old code below





exports.addState = async (req, res) => {
    try {
        const { state_name, country_id } = req.body;
        if (!state_name || !country_id) {
            return sendError(res, { message: "Please provide both state name and country id." });
        }

        await runQuery(`INSERT INTO states (name, country_id) VALUES (?, ?)`, [state_name, country_id]);
        return sendSuccess(res, { message: "State has been added successfully." });
    } catch (error) {
        return sendError(res, { message: error.message });
    }
}


exports.addCity = async (req, res) => {
    try {
        const { state_id, city_name } = req.body
        if (!city_name) {
            return sendError(res, { message: "Please enter the city name..." })
        }
        const stateData = await runQuery(`select * from states where state_id = ?`, [state_id])
        if (stateData.length > 0) {
            await runQuery(`insert into cities set state_id = ?, city_name = ?`, [state_id, city_name])
            return sendSuccess(res, { message: "City has been added successfully..." })
        } else {
            return sendError(res, { message: "Please select the valid state..." })
        }
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}


//done 





exports.cityAutoComplete = async (req, res) => {
    const { search = "" } = req.query;
    try {
        let query = `select * from cities`;
        let value = [];
        if (search) {
            query += ` WHERE name LIKE ?`;
            value.push(`%${search}%`);
        }
        query += ` LIMIT ? OFFSET ?`;
        const data = await runQuery(query, [...value, 100, 0]);
        return sendSuccess(res, { data: data, message: "City list..." })
    } catch (error) {
        return sendError(res, { message: error.message })
    }
}