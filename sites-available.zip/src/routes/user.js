const route = require('express').Router()

const { stateList, stateCities, cityList, salaryList, jobType, jobLevel, experience, resultType, categories, subCategories } = require('../controllers/common')
const { registartion, setNewPassword, userProfile,
    signInWithEmailAndPwd, registartionAdditionalInformation, uploadProfileImage, uploadResume, resumeList, viewResume, addEducation, addExperience, registartionOTP, mobileSendOTP, mobileVerifyOTP } = require('../controllers/users/authetication')
const { registrationCallUsers, callLogLogin, uploadCallLogs, usersCallList, callUserProfile, callChangePassword } = require('../controllers/users/callLogs')
const { applyJob, searchJob, answerSecreenQuestions, appliedJobs, savedJobs, removeSavedJob, saveJob } = require('../controllers/users/jobs')
const { facultyLanguage, facultyEducation, facultyCareerPreference, facultyCertificate, facultyCityPreference, facultyExperience, facultySkill, facultyAllData } = require('../controllers/users/profile')
const { callMiddleware } = require('../middlewares/callMiddleware')
const { userMiddleware } = require('../middlewares/userMiddleware')
const { UserProfile, UserResume } = require('../utils/filesPath')
const { uploadImage, uploadDocument } = require('../utils/fileUploader')



// Common Api's
route.get("/state", stateList)
    .get("/stateCities", stateCities)
    .get("/allCities", cityList)
    .get("/allSalary", salaryList)
    .get("/jobType", jobType)
    .get("/jobLevel", jobLevel)
    .get("/jobExperience", experience)
    .get("/jobResultType", resultType)
    .get("/categories", categories)
    .get("/subCategories", subCategories)
    // Profile Get Api's 
    .get("/facultyLanguage", facultyLanguage)
    .get("/facultyEducation", facultyEducation)
    .get("/facultyCareerPreference", facultyCareerPreference)
    .get("/facultyCertificate", facultyCertificate)
    .get("/facultyCityPreference", facultyCityPreference)
    .get("/facultyExperience", facultyExperience)
    .get("/facultySkill", facultySkill)
    .get("/facultyAllData", facultyAllData)
    // Profile Post Api's 



// .post("/authentication/registration-send-otp", registartionOTP)
// .post("/authentication/registration-verify-otp", registartion)
// .post("/profile/additional-information", userMiddleware(), registartionAdditionalInformation)
// .get("/profile", userMiddleware(), userProfile)
// .patch("/profile/set-password", userMiddleware(), setNewPassword)
// .post("/profile/profile-image", uploadImage(UserProfile).single('profile_image'), userMiddleware(), uploadProfileImage)
// .post("/profile/resume", uploadDocument(UserResume).single("resume"), userMiddleware(), uploadResume)
// .get("/profile/resume", userMiddleware(), resumeList)
// .post("/profile/add-eduction", userMiddleware(), addEducation)
// .post("/profile/add-experience", userMiddleware(), addExperience)
// .get("/profile/resume/:rs_id", userMiddleware(), viewResume)
// .post("/login/mobile-send-otp", mobileSendOTP)
// .post("/login/mobile-verify-otp", mobileVerifyOTP)
// .post("/login/signInWithMail", signInWithEmailAndPwd)
// .get("/job/search-job", userMiddleware(), searchJob)
// .post("/job/apply-job", userMiddleware(), applyJob)
// .post("/job/answer-screening-questions", userMiddleware(), answerSecreenQuestions)
// .get("/job/applied-jobs", userMiddleware(), appliedJobs)
// .post("/job/save-job", userMiddleware(), saveJob)
// .delete("/job/remove-job/:saved_id", userMiddleware(), removeSavedJob)
// .get("/job/saved-jobs", userMiddleware(), savedJobs)



/**
 * 
 * Call logs apis
 */

// .post("/call-log/registration", registrationCallUsers)
// .post("/call-log/login", callLogLogin)
// .post("/call-log/upload", callMiddleware(), uploadCallLogs)
// .get("/call-log/users", callMiddleware(), usersCallList)
// .post("/call-log/change-password", callMiddleware(), callChangePassword)
// .get("/call-log/profile", callMiddleware(), callUserProfile)


module.exports = route