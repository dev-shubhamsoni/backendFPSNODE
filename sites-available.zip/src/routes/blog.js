// const route = require('express').Router()
// const { createBlogPost } = require('../controllers/blog/blog')

// route.post("/createBlogPost",createBlogPost)