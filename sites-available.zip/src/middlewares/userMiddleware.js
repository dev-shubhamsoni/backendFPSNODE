const { sendError } = require("../utils/commonFunctions")
const { runQuery } = require("../utils/executeQuery")
const fs = require('fs')
const { verifyJWTToken } = require("../utils/jwtHandler")

exports.userMiddleware = () => {
    return async (req, res, next) => {
        const bearerHeader = req.headers["authorization"]
        if (typeof bearerHeader !== 'undefined') {
            try {
                const token = bearerHeader.split(" ")[1]
                const data = await verifyJWTToken(token)
                const dataUser = await runQuery(`select * from users where u_id = ?`, [data.u_id])
                if (dataUser.length > 0) {
                    if (dataUser[0].is_employer == 1) {
                        req.body.u_id = data.u_id
                        next()
                    } else {
                        return sendError(res, { message: "You'r account has been deactivated..." })
                    }

                } else {
                    return sendError(res, { message: "Invalid Token..." })
                }

            } catch (error) {
                if(req.file !== undefined){
                    fs.unlinkSync(req.file.path)
                }
                return sendError(res, { message: error.message })
            }
        } else {
            if(req.file !== undefined){
                fs.unlinkSync(req.file.path)
            }
            return sendError(res, { message: "Please provide token..." })
        }
    }
}