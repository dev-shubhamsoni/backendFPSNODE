const express = require("express");
const dotenv = require("dotenv");
const http = require("http");
const bodyParser = require("body-parser");
dotenv.config({ path: "./.env" });
/* const cors = require("cors"); */

const app = express();
const server = http.createServer(app);
const socketUtils = require("./utils/socketHandler");

// Middleware
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));
/* var corsOptions = {
  origin: "*"
};
app.use(cors(corsOptions)); */
app.set("view engine", "ejs");

// Body parser middleware (if you choose to use it)
// app.use(bodyParser.json({ limit: '50mb' }));
// app.use(bodyParser.urlencoded({ limit: '50mb', extended: true, parameterLimit: 50000 }));

// Routes
const adminRoute = require("./routes/admin");
const instituteRoute = require("./routes/institute");
const userRoute = require("./routes/user");

app.use("/admin", adminRoute);
app.use("/institute", instituteRoute);
app.use("/user", userRoute);

// Web Socket
socketUtils.setupSocket(server);

// const PORT = process.env.PORT || 3000
const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server is started on port ${PORT}`);
});

app.use("/uploads", express.static("uploads"));
// Login Token
// glpat-ShE4Rqn2c8JztQJE6iJp
