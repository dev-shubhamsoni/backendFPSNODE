//  exports.InstituteLOGO = "Images/institutions-logo"
 exports.UserProfile = "Images/user-profile"
 exports.UserResume = "Images/user-resumes"


exports.InstituteLOGO = "uploads/institute"