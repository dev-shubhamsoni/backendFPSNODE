const crypto = require('crypto')

const sendError = (res, { data = [], message, code = 400 }) => {
    res.json({
        status: false,
        statusCode: code,
        data: data,
        message: message
    })
}


const sendSuccess = (res, { data = [], message, code = 200 }) => {
    res.json({
        status: true,
        statusCode: code,
        data: data,
        message: message
    })
}
const sendPaginationSuccess = (res, { data = [],total_data = 0, message, code = 200 }) => {
    res.json({
        status: true,
        statusCode: code,
        data: data,
        total_data:total_data,
        message: message
    })
}

function generateUniqueString(length) {
    return crypto.randomBytes(Math.ceil(length/2))
        .toString('hex')
        .slice(0, length);
}


module.exports = {
    sendError,
    sendSuccess,
    sendPaginationSuccess,
    generateUniqueString
}